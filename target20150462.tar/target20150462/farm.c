/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_371()
{
    return 2428995912U;
}

void setval_312(unsigned *p)
{
    *p = 3347663062U;
}

unsigned getval_137()
{
    return 2462550344U;
}

unsigned addval_497(unsigned x)
{
    return x + 2421722746U;
}

unsigned getval_414()
{
    return 3243778944U;
}

unsigned addval_157(unsigned x)
{
    return x + 329040728U;
}

unsigned addval_300(unsigned x)
{
    return x + 2425362452U;
}

void setval_289(unsigned *p)
{
    *p = 3284633864U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_385(unsigned x)
{
    return x + 2497743176U;
}

unsigned addval_467(unsigned x)
{
    return x + 2430634248U;
}

void setval_311(unsigned *p)
{
    *p = 3373846921U;
}

unsigned addval_288(unsigned x)
{
    return x + 3375940232U;
}

unsigned getval_109()
{
    return 3269495112U;
}

unsigned getval_248()
{
    return 3286276424U;
}

unsigned addval_405(unsigned x)
{
    return x + 3376992649U;
}

unsigned getval_271()
{
    return 3286272328U;
}

void setval_387(unsigned *p)
{
    *p = 3526938249U;
}

unsigned addval_448(unsigned x)
{
    return x + 3677930153U;
}

unsigned addval_363(unsigned x)
{
    return x + 918802825U;
}

unsigned getval_116()
{
    return 2425540233U;
}

unsigned addval_145(unsigned x)
{
    return x + 2059915657U;
}

unsigned addval_186(unsigned x)
{
    return x + 3232026249U;
}

unsigned addval_254(unsigned x)
{
    return x + 2425409161U;
}

unsigned getval_418()
{
    return 3378561673U;
}

void setval_272(unsigned *p)
{
    *p = 3676357257U;
}

unsigned addval_470(unsigned x)
{
    return x + 3374895497U;
}

unsigned getval_489()
{
    return 3526410889U;
}

void setval_159(unsigned *p)
{
    *p = 3221278345U;
}

unsigned getval_463()
{
    return 3268512157U;
}

unsigned getval_149()
{
    return 3372794505U;
}

unsigned addval_182(unsigned x)
{
    return x + 3526935241U;
}

unsigned addval_362(unsigned x)
{
    return x + 3286272328U;
}

void setval_215(unsigned *p)
{
    *p = 3682914729U;
}

unsigned getval_127()
{
    return 3286272344U;
}

void setval_498(unsigned *p)
{
    *p = 3229929113U;
}

unsigned addval_117(unsigned x)
{
    return x + 3536110217U;
}

unsigned getval_128()
{
    return 2497743176U;
}

void setval_282(unsigned *p)
{
    *p = 3251538373U;
}

void setval_434(unsigned *p)
{
    *p = 1975701129U;
}

unsigned addval_217(unsigned x)
{
    return x + 3281047945U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
